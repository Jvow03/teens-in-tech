# Teens in Tech
Full project with Firebase & Admin Panel